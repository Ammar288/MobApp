﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            beverage b = new houseblend();
            Console.WriteLine(b.getDescription()+ " " + b.cost());
            Console.ReadKey();

        }
    }
    
    abstract class beverage
    {
        public string description = "Beverage";

        public virtual string getDescription()
        {
            return description;
        }
        public abstract double cost();
    }

    abstract class condimentDecorator : beverage
    {
        
    }

    class houseblend : beverage
    {
        public override string getDescription()
        {
            return "Houseblend";
        }
        public override double cost()
        {
            return 4;
        }
    }
    class darkroast : beverage
    {
        public override string getDescription()
        {
            return "darkroast";
        }
        public override double cost()
        {
            return 3;
        }
    }
    class espresso : beverage
    {
        public override string getDescription()
        {
            return "Espreso";
        }
        public override double cost()
        {
            return 5;
        }
    }
    class dcaf : beverage
    {
        public override string getDescription()
        {
            return "Dcaf";
        }
        public override double cost()
        {
            return 6;
        }
    }

    class milk : condimentDecorator
    {
        public override string getDescription()
        {
            return "Milk";
        }
        public override double cost()
        {
            return 2.5;
        }
    }

    class mocha : condimentDecorator
    {
        public override string getDescription()
        {
            return "Mocha";
        }
        public override double cost()
        {
            return 2;
        }
    }

    class soy : condimentDecorator
    {
        public override string getDescription()
        {
            return "Soy";
        }
        public override double cost()
        {
            return 1.5;
        }
    }

    class whip : condimentDecorator
    {
        public override string getDescription()
        {
            return "Espreso";
        }
        public override double cost()
        {
            return 1;
        }
    }


}
